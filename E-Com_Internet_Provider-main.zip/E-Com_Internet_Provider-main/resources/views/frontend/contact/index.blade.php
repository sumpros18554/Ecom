@extends('frontend.layout.master')

@section('title', 'Contact Us - GovConnectNet')
@section('contact_active', 'active')
@section('content')

    <section>
        <h2>Get in Touch with GovConnectNet</h2>
        <p>
            We’re here to assist you with your connectivity needs, procurement inquiries, or any questions about our
            projects and services.
            Reach out to us via any of the following channels, or simply fill out the contact form below and our team
            will respond promptly.
        </p>

        <div class="contact-info">
            <h3>Contact Details</h3>
            <p><strong>Address:</strong> #12, Street 289, Phnom Penh, Cambodia</p>
            <p><strong>Email:</strong> info@govconnectnet.kh</a></p>
            <p><strong>Phone:</strong> +855 23 456 789</p>
            <p><strong>Office Hours:</strong> Monday - Friday, 8:00 AM – 6:00 PM</p>
        </div>

        <div class="contact-form">
            <h3>Send Us a Message</h3>
            <form action="{{ route('contact.send') }}" method="POST">
                @csrf

                <label for="name">Name</label>
                <input type="text" id="name" name="name" value="{{ old('name') }}" placeholder="Your Full Name"
                    required />
                @error('name')
                    <div class="error">{{ $message }}</div>
                @enderror

                <label for="email">Email</label>
                <input type="email" id="email" name="email" value="{{ old('email') }}"
                    placeholder="Your Email Address" required />
                @error('email')
                    <div class="error">{{ $message }}</div>
                @enderror

                <label for="subject">Subject</label>
                <input type="text" id="subject" name="subject" value="{{ old('subject') }}"
                    placeholder="Subject of Your Message" required />
                @error('subject')
                    <div class="error">{{ $message }}</div>
                @enderror

                <label for="message">Message</label>
                <textarea id="message" name="message" placeholder="Write your message here..." rows="6" required>{{ old('message') }}</textarea>
                @error('message')
                    <div class="error">{{ $message }}</div>
                @enderror

                <input type="submit" value="Send Message" />
            </form>
        </div>

        <div id="successModal" class="modal">
            <div class="modal-content">
                <span class="close">&times;</span>
                <div class="modal-header">
                    <span class="modal-icon">
                        <i class="fa-regular fa-circle-check" style="color:green; font-size:100px"></i>
                    </span>
                    <h3>Success</h3>
                </div>
                <p>{!! session('success') !!}</p>
            </div>
        </div>

        <div id="failedModal" class="modal">
            <div class="modal-content">
                <span class="close">&times;</span>
                <div class="modal-header">
                    <span class="modal-icon">
                        <i class="fa-regular fa-circle-xmark" style="color:red; font-size:100px"></i>
                    </span>
                    <h3>Failed</h3>
                </div>
                <p>{!! session('failed') !!}</p>
            </div>
        </div>

    </section>


@endsection
