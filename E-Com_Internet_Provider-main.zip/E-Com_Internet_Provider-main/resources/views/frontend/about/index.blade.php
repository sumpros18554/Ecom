@extends('frontend.layout.master')

@section('title', 'About Us - GovConnectNet')
@section('about_active', 'active')
@section('content')

    <!-- About Us -->
    <section>
        <div class="section-image">
            <img src="{{ asset($img_path.'corporation.jpeg') }}" alt="Who We Are" />
        </div>
        <h2>Who We Are</h2>
        <p>
            GovConnectNet Co. Ltd. is a Cambodian technology company dedicated to delivering secure, high-performance
            internet and digital infrastructure solutions exclusively for public institutions.
            As a government-focused internet service provider (ISP), our goal is to ensure that ministries, hospitals,
            schools, and government offices are connected, protected, and empowered to serve the people efficiently.
        </p>
    </section>

    <!-- Our History -->
    <section>
        <div class="section-image">
            <img src="{{ asset($img_path.'office.jpeg') }}" alt="Who We Are" />
        </div>
        <h2>Our History</h2>
        <p>
            GovConnectNet was established in 2022 as a result of Cambodia’s National Digital Government Policy
            initiative.
            We began as a joint effort between leading ICT professionals and public infrastructure experts who
            recognized the urgent need for a reliable, government-exclusive connectivity solution.
        </p>
        <p>
            Since then, we have deployed over 2,000 km of fiber-optic cable, built direct connections with national data
            centers, and helped rural districts gain access to essential internet services.
        </p>
    </section>

    <!-- Our Partnerships -->
    <section>
        <div class="section-image">
            <img src="{{ asset($img_path.'handshack.jpeg') }}" alt="Who We Are" />
        </div>

        <h2>Strategic Partnerships</h2>
        <p>
            We work closely with the Ministry of Posts and Telecommunications (MPTC), Ministry of Interior, Ministry of
            Health, and the Ministry of Education, Youth and Sport.
            These partnerships enable us to deliver infrastructure aligned with national policies and digital
            transformation objectives.
        </p>
        <ul>
            <li>🤝 Public-private partnerships with local ISPs and infrastructure builders</li>
            <li>🌐 Integration with national ID, passport, and e-health systems</li>
            <li>🛡️ Consultation with cybersecurity regulators for secure implementation</li>
        </ul>
    </section>

    <!-- Organizational Structure -->
    <section>
        <div class="section-image">
            <img src="{{ asset($img_path.'team.webp') }}" alt="Who We Are" />
        </div>

        <h2>Our Team & Governance</h2>
        <p>
            GovConnectNet is managed by a board of directors with experience in telecommunications, cybersecurity, and
            public sector innovation.
            Our teams include network engineers, government liaison officers, cybersecurity analysts, and IT
            infrastructure planners.
        </p>
        <p>
            We follow transparent procurement procedures and conduct regular internal audits to maintain public trust
            and service accountability.
        </p>
    </section>

    <!-- Commitment to Innovation -->
    <section>
        <div class="section-image">
            <img src="{{ asset($img_path.'Innovation.jpg') }}" alt="Who We Are" />
        </div>

        <h2>Our Commitment to Innovation</h2>
        <p>
            We believe that technology should serve governance, not the other way around. Our R&D team is continuously
            exploring new tools like satellite backup networks, AI-assisted monitoring, and automated maintenance to
            ensure high availability and efficiency.
        </p>
        <p>
            We are also committed to digital inclusion—bringing internet to rural communities and remote health centers
            where access is most needed.
        </p>
    </section>

@endsection
