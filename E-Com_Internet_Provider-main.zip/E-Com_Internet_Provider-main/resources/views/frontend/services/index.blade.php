@extends('frontend.layout.master')

@section('title', 'Services - GovConnectNet')
@section('services_active', 'active')
@section('content')

<section>
    <h2>-- Our Core Services --</h2>
    <p>
        GovConnectNet specializes in delivering secure, high-speed internet and digital infrastructure tailored
        specifically for government entities. Our services are designed to meet stringent security requirements
        while ensuring uninterrupted connectivity.
    </p>
    <br>


    <div class="service-block">
        <img src="{{ asset($img_path.'fiber-optic.cms') }}" alt="Fiber Optic Network">
        <h3>1. Government Fiber-Optic Networks</h3>
        <p>
            We deploy dedicated fiber-optic networks connecting ministries, public hospitals, schools, and regional
            offices. These private networks provide enhanced bandwidth, reliability, and security unavailable through
            commercial ISPs.
        </p>
    </div>

    <div class="service-block">
        <img src="{{ asset($img_path.'data-security.jpg') }}" alt="Cybersecurity">
        <h3>2. Cybersecurity & Data Protection</h3>
        <p>
            Our cybersecurity services include firewall management, intrusion detection systems, encrypted VPNs, and
            ongoing security audits. We ensure your sensitive government data is protected against cyber threats.
        </p>
    </div>

    <div class="service-block">
        <img src="{{ asset($img_path.'monitor.jpg') }}" alt="Network Monitoring">
        <h3>3. Network Monitoring & Maintenance</h3>
        <p>
            Our 24/7 network operations center monitors all infrastructure for potential issues. We proactively conduct
            maintenance, rapid troubleshooting, and immediate incident response to minimize downtime.
        </p>
    </div>

    <div class="service-block">
        <img src="{{ asset($img_path.'initiatives.jpg') }}" alt="Digital Inclusion">
        <h3>4. Digital Inclusion Initiatives</h3>
        <p>
            Partnering with ministries of education and health, we help extend internet access to underserved rural
            communities. Our satellite backup solutions keep essential government services online during emergencies.
        </p>
    </div>

    <div class="service-block">
        <img src="{{ asset($img_path.'consulting.jpg') }}" alt="Custom Solutions">
        <h3>5. Custom Solutions & Consulting</h3>
        <p>
            We offer personalized consultations and custom-built network architectures for special projects such as
            e-governance platforms, digital identity systems, and smart city initiatives.
        </p>
    </div>

    <div style="text-align: center;">
        <button onclick="location.href='{{ route('contact') }}'">Request a Service Consultation</button>
    </div>
</section>

@endsection
