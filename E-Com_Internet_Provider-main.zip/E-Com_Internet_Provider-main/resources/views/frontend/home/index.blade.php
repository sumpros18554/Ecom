@extends('frontend.layout.master')

@section('title', 'Home - GovConnectNet')
@section('home_active', 'active')
@section('content')

<!-- Welcome Section -->
<section class="content-section">
    <div class="image-container">
        <img src="{{ asset($img_path.'corporation.jpeg') }}" alt="Welcome Image" />
    </div>
    <div class="text-container">
        <h2>Welcome to GovConnectNet</h2>
        <p>
            GovConnectNet is Cambodia’s first specialized internet service provider dedicated exclusively to
            supporting public sector infrastructure.
            Our mission is to ensure that ministries, government hospitals, schools, and other public institutions
            have access to secure, stable, and
            high-speed internet that meets national digital transformation goals.
        </p>
        <p>
            We design connectivity solutions tailored to government needs—from secure data centers and private VPNs
            to rural school internet expansion.
            Whether it's building national digital ID systems or providing hospital bandwidth for telemedicine, our
            work is aligned with Cambodia’s e-government strategy.
        </p>
        <button onclick="location.href='{{ route('service') }}'">Explore Our Services</button>
    </div>
</section>

<!-- Company Overview -->
<section class="content-section">
    <div class="image-container">
        <img src="{{ asset($img_path.'serverRoom.jpg')}} " alt="Company Overview Image" />
    </div>
    <div class="text-container">
        <h2>About GovConnectNet</h2>
        <p>
            Founded in 2022 as part of Cambodia’s national digital development initiative, GovConnectNet Co. Ltd.
            works under public-private partnerships
            to deploy internet and infrastructure services across key state institutions. We provide:
        </p>
        <ul>
            <li>🔌 Fiber-optic network expansion for rural districts</li>
            <li>🛡️ Cybersecurity and firewall setup for ministries</li>
            <li>📡 Secure satellite backup for disaster recovery zones</li>
            <li>📈 Monitoring and analytics tools for digital government platforms</li>
        </ul>
    </div>
</section>

<!-- Mission Section -->
<section class="content-section">
    <div class="image-container">
        <img src="{{ asset($img_path.'mission.jpg') }}" alt="Mission Image" />
    </div>
    <div class="text-container">
        <h2>Our Mission</h2>
        <p>
            To empower Cambodia’s public institutions by delivering robust and secure internet connectivity that
            drives transparency, efficiency,
            and citizen-centered digital services. We aim to be the digital backbone of government by making every
            megabit matter.
        </p>
    </div>
</section>

<!-- Core Values -->
<section class="content-section">
    <div class="image-container">
        <img src="{{ asset($img_path.'reliable.png') }}" alt="Core Values Image" />
    </div>
    <div class="text-container">
        <h2>Our Core Values</h2>
        <ul>
            <li><strong>Reliability:</strong> We offer guaranteed uptime and fast recovery plans.</li>
            <li><strong>Security:</strong> All services meet military-grade security standards.</li>
            <li><strong>Adaptability:</strong> Custom network solutions based on institutional needs.</li>
            <li><strong>Trust:</strong> Long-term contracts with transparency and accountability.</li>
        </ul>
    </div>
</section>

<!-- Why Choose Us Section -->
<section class="content-section">
    <div class="image-container">
        <img src="{{ asset($img_path.'security.webp') }}" alt="Why Choose Us Image" />
        <img src="{{ asset($img_path.'speed.webp') }}" style="margin-top: 20px;" alt="Why Choose Us Image" />
    </div>
    <div class="text-container">
        <h2>Why Choose GovConnectNet?</h2>

        <div class="service">
            <img src="https://cdn-icons-png.flaticon.com/512/7581/7581668.png" class="icon" alt="Security" />
            <div>
                <h3>🔒 Secure Infrastructure</h3>
                <p>
                    We build networks with built-in encryption, government-level firewalls, and segmented access to
                    protect national data. Our systems
                    are compliant with international cybersecurity standards.
                </p>
            </div>
        </div>

        <div class="service">
            <img src="https://cdn-icons-png.flaticon.com/512/7154/7154506.png" class="icon" alt="Speed" />
            <div>
                <h3>⚡ High-Speed Connectivity</h3>
                <p>
                    Using Cambodia’s national fiber backbone and dedicated IP addresses, we provide consistently
                    fast internet—even in remote government
                    offices and schools in rural provinces.
                </p>
            </div>
        </div>

        <div class="service">
            <img src="https://cdn-icons-png.flaticon.com/512/5610/5610944.png" class="icon" alt="Support" />
            <div>
                <h3>🛠️ Government-Only Support</h3>
                <p>
                    Our engineers are trained to support mission-critical systems. From IT troubleshooting to
                    emergency reboots, our helpdesk is staffed
                    24/7 for government clients only.
                </p>
            </div>
        </div>
    </div>
</section>

<!-- How We Work -->
<section class="content-section">
    <div class="image-container">
        <img src="{{ asset($img_path.'boardroom.jpg') }}" alt="How We Work Image" />
    </div>
    <div class="text-container">
        <h2>How We Work</h2>
        <p>
            Our approach is deeply collaborative. We work directly with national and sub-national departments to
            assess needs, draft network designs,
            conduct site surveys, and deploy solutions. All of our infrastructure projects are managed in close
            coordination with the Ministry of
            Posts and Telecommunications (MPTC).
        </p>
    </div>
</section>

<!-- Quick Stats -->
<section class="content-section">
    <div class="image-container">
        <img src="{{ asset($img_path.'impact.jpg') }}" alt="Quick Stats Image" />
    </div>
    <div class="text-container">
        <h2>Our Impact</h2>
        <ul>
            <li>📍 Connected 300+ public schools with fast, filtered internet access</li>
            <li>🏥 Enabled secure telehealth platforms in 40+ provincial hospitals</li>
            <li>🏛️ Partnered with 12 national ministries for data integration</li>
            <li>📡 98.9% network uptime from 2024–2025 (ISO-monitored)</li>
        </ul>
    </div>
</section>

<!-- Call to Action -->
<section class="content-section">
    <div class="image-container">
        <img src="{{ asset($img_path.'contactus.jpg') }}" alt="Call to Action Image" />
    </div>
    <div class="text-container">
        <h2>Ready to Modernize Your Infrastructure?</h2>
        <p>
            Contact us today to schedule a free consultation. Our expert advisors will assess your digital readiness
            and propose a custom internet
            or network solution designed to meet your ministry’s operational goals.
        </p>
        <button onclick="location.href='{{ route('contact') }}'">Request a Consultation</button>
    </div>
</section>

@endsection
