<header class="hero-header">
    <div class="header-content">
        <img src="{{ asset($img_path.'logo.png') }}" alt="GovConnectNet Logo" class="logo" />
        <div>
            <h1>GovConnectNet Co. Ltd.</h1>
            <p class="tagline">Secure Connectivity for Government Nationwide</p>
        </div>
    </div>
    <nav>
        <a href="{{ route('home') }}" class="@yield('home_active')">Home</a>
        <a href="{{ route('about') }}" class="@yield('about_active')">About</a>
        <a href="{{ route('service') }}" class="@yield('services_active')">Services</a>
        <a href="{{ route('project') }}" class="@yield('projects_active')">Projects</a>
        <a href="{{ route('contact') }}" class="@yield('contact_active')">Contact</a>
    </nav>
</header>
