<footer>
    <p>&copy; 2025 GovConnectNet Co. Ltd. | All Rights Reserved</p>
</footer>
