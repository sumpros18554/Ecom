<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>@yield('title')</title>
    <link rel="icon" href="{{ asset($img_path . 'logo.png') }}" type="image/png">

    <link rel="stylesheet" href="{{ asset('frontend/css/style.css') }}">
    <link rel="stylesheet" href="{{ asset('frontend/css/modal.css') }}">
    <link rel="stylesheet" href="{{ asset('frontend/vendor/fontawesome-free-7.0.0-web/css/all.min.css') }}">

</head>

<body>

    @include('frontend.layout.header')

    @yield('content')

    @include('frontend.layout.footer')
    
    @if (session('success') || session('failed'))
        <script>
            document.addEventListener('DOMContentLoaded', function() {
                @php
                    $modalId = session('success') ? 'successModal' : (session('failed') ? 'failedModal' : null);
                @endphp

                const modal = document.getElementById("{{ $modalId }}");

                if (modal) {
                    const closeBtn = modal.querySelector(".close");

                    modal.style.display = "block";

                    if (closeBtn) {
                        closeBtn.onclick = function() {
                            modal.style.display = "none";
                        };
                    }

                    window.onclick = function(event) {
                        if (event.target === modal) {
                            modal.style.display = "none";
                        }
                    };
                }
            });
        </script>
    @endif



</body>

</html>
