@extends('frontend.layout.master')

@section('title', 'Projects - GovConnectNet')
@section('project_active', 'active')
@section('content')

    <section>
    <h2>Our Flagship Projects</h2>
    <p>
        GovConnectNet has spearheaded numerous large-scale projects supporting Cambodia’s national digital agenda.
        Below are some highlights demonstrating our impact and capabilities.
    </p>

    <div class="project-card id-project" style="background-image: url({{asset($img_path.'digital-id.png')}})">
        <div class="overlay">
            <h3>National Digital ID Network</h3>
            <p>
                Developed in collaboration with the Ministry of Interior, this project provides a secure, fast, and reliable
                network infrastructure to support Cambodia’s national ID registration and verification systems.
            </p>
        </div>
    </div>

    <div class="project-card school-project" style="background-image: url({{asset($img_path.'expansion.webp')}})">
        <div class="overlay">
            <h3>Rural School Internet Expansion</h3>
            <p>
                Over 300 public schools in rural provinces now have high-speed fiber connections, enabling digital learning
                and access to educational resources.
            </p>
        </div>
    </div>

    <div class="project-card hospital-project" style="background-image: url({{asset($img_path.'hospital.jpg')}})">
        <div class="overlay">
            <h3>Provincial Hospital Telehealth Network</h3>
            <p>
                Established a dedicated network to connect 40 provincial hospitals to centralized health data centers,
                enabling telemedicine consultations and real-time patient data sharing.
            </p>
        </div>
    </div>

    <div class="project-card disaster-project" style="background-image: url({{asset($img_path.'recovery.png')}})">
        <div class="overlay">
            <h3>Disaster Recovery and Backup Systems</h3>
            <p>
                Designed and deployed satellite-based backup internet solutions in disaster-prone areas, ensuring government
                operations remain online during emergencies.
            </p>
        </div>
    </div>
</section>

@endsection
